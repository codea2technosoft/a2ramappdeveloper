package com.example.rajasthani_real_estates

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
