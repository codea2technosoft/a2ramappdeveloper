import 'package:get_storage/get_storage.dart';

var box = GetStorage();

userName() {
  var userName = box.read('userName');
  return userName ?? '';
}

userMobile() {
  var userMobile = box.read('userMobile');
  return userMobile ?? '';
}

userPassword() {
  var userPassword = box.read('userPassword');
  return userPassword ?? '';
}
