import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';

class KycPageView extends StatefulWidget {
  const KycPageView({super.key});

  @override
  State<KycPageView> createState() => _KycPageViewState();
}

class _KycPageViewState extends State<KycPageView> {
  File? _selectedImage;
  final TextEditingController panNoController = TextEditingController();
  final TextEditingController adharNoController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  Future<void> _pickImageFromGallery() async {
    try {
      final XFile? pickedFile =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedFile != null && pickedFile.path.isNotEmpty) {
        setState(() {
          _selectedImage = File(pickedFile.path);
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("No image selected.")),
        );
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("KYC"),
        centerTitle: true,
        backgroundColor: Colors.green.shade700,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              height15,
              const Text(
                "Complete KYC",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              height10,
              const Text(
                "Upload your PAN & Aadhaar details to complete verification.",
                style: TextStyle(color: Colors.grey),
              ),height30,
              const Text("PAN Number",
                  style: TextStyle(fontWeight: FontWeight.w600)),
              height10,
              TextFormField(
                controller: panNoController,
                decoration: InputDecoration(
                  hintText: "Enter your PAN number",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter PAN number';
                  }
                  return null;
                },
              ),
height20,
              const Text("Aadhaar Number",
                  style: TextStyle(fontWeight: FontWeight.w600)),
             height10,
              TextFormField(
                controller: adharNoController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: "Enter Aadhaar number",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Aadhaar number';
                  } else if (value.length < 12) {
                    return 'Aadhaar must be 12 digits';
                  }
                  return null;
                },
              ),

              height30,
              const Text("Upload Document Image",
                  style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: _pickImageFromGallery,
                child: Container(
                  height: 180,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade400),
                    color: Colors.grey.shade100,
                  ),
                  child: _selectedImage == null
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt,
                                  size: 50, color: Colors.grey),
                              height10,
                              Text("Tap to select image",
                                  style: TextStyle(color: Colors.grey)),
                            ],
                          ),
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(
                            _selectedImage!,
                            fit: BoxFit.cover,
                          ),
                        ),
                ),
              ),
              height40,
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      if (_selectedImage == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text("Please upload an image")),
                        );
                      } else {
                        // Upload logic
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("KYC Submitted!")),
                        );
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child:
                      const Text("Submit KYC", style: TextStyle(fontSize: 16)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
