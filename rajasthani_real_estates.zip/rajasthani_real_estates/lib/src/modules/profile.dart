import 'package:flutter/material.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';

class ProfilePageView extends StatefulWidget {
  const ProfilePageView({super.key});

  @override
  State<ProfilePageView> createState() => _ProfilePageViewState();
}

class _ProfilePageViewState extends State<ProfilePageView> {
  List estateList = [
    {
      'title': 'Wings Tower',
      'price': 'Rent',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/house.png',
    },
    {
      'title': 'Wings Tower',
      'price': 'Rent',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/mahal.jpg',
    },
    {
      'title': 'Wings Tower',
      'price': 'Rent',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/splashbg.png',
    },
    {
      'title': 'Wings Tower',
      'price': 'Rent',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/whitehouse.jpg',
    },
  ];
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Profile',
            style: TextStyle(color: Color(0xFF252B5C)),
          ),
          centerTitle: true,
          actions: const [
            Icon(Icons.settings_outlined, color: Color(0xFF234F68)),
            SizedBox(width: 10),
          ],
        ),
        body: Column(
          children: [
            Align(
              alignment: Alignment.center,
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: Image.asset(
                      'assets/img/man.jpg',
                      width: 150,
                      height: 150,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                      bottom: 15,
                      right: 0,
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Color(0xFF234F68)),
                        child: Icon(
                          Icons.edit,
                          color: Colors.white,
                        ),
                      ))
                ],
              ),
            ),
            const SizedBox(height: 10),
            const Text('Ankit Kumar', style: TextStyle(fontSize: 18)),
            const Text('ankitkumar@gmail.com', style: TextStyle(fontSize: 12)),
            height20,
            const TabBar(
              labelColor: Colors.black,
              indicatorColor: Colors.green,
              tabs: [
                Tab(text: 'Transaction'),
                Tab(text: 'Activity'),
                Tab(text: 'Sold'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  SingleChildScrollView(
                    padding: EdgeInsets.all(5),
                    child: GridView.builder(
                      itemCount: estateList.length,
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 2,
                        mainAxisSpacing: 14,
                        childAspectRatio: 0.72,
                      ),
                      itemBuilder: (context, index) {
                        return estateCard(
                          isFavorite: true,
                          title: estateList[index]['title']!,
                          price: estateList[index]['price']!,
                          rating: estateList[index]['rating']!,
                          location: estateList[index]['location']!,
                          imagePath: estateList[index]['imagePath']!,
                        );
                      },
                    ),
                  ),
                  SingleChildScrollView(
                    padding: EdgeInsets.all(5),
                    child: GridView.builder(
                      itemCount: estateList.length,
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 2,
                        mainAxisSpacing: 14,
                        childAspectRatio: 0.72,
                      ),
                      itemBuilder: (context, index) {
                        return estateCard(
                          isFavorite: true,
                          title: estateList[index]['title']!,
                          price: estateList[index]['price']!,
                          rating: estateList[index]['rating']!,
                          location: estateList[index]['location']!,
                          imagePath: estateList[index]['imagePath']!,
                        );
                      },
                    ),
                  ),
                  Center(child: Text('Sold')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget estateCard({
  required String title,
  required String price,
  required String rating,
  required String location,
  required String imagePath,
  required bool isFavorite,
}) {
  return Container(
    width: 180,
    margin: const EdgeInsets.only(right: 16),
    padding: const EdgeInsets.only(bottom: 20),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
              child: Image.asset(
                imagePath,
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: isFavorite ? Colors.pink[100] : Colors.green[100],
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isFavorite ? Icons.favorite : Icons.favorite_border,
                  size: 16,
                  color: isFavorite ? Colors.pink : Colors.green,
                ),
              ),
            ),
            Positioned(
              bottom: 10,
              left: 10,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A6666),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  price,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ),
              ),
            )
          ],
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              height5,
              Row(
                children: [
                  const Icon(Icons.star, color: Colors.orange, size: 14),
                  width5,
                  Text(
                    rating,
                    style: const TextStyle(fontSize: 12),
                  ),
                  width5,
                  const Icon(Icons.location_on, color: Colors.grey, size: 14),
                  const SizedBox(width: 2),
                  Expanded(
                    child: Text(
                      location,
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    ),
  );
}
