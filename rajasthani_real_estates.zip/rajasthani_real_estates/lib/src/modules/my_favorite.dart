import 'package:flutter/material.dart';

import '../constant/size.dart';

class MyFavoritePageView extends StatefulWidget {
  const MyFavoritePageView({super.key});

  @override
  State<MyFavoritePageView> createState() => _MyFavoritePageViewState();
}

class _MyFavoritePageViewState extends State<MyFavoritePageView> {
  List estateList = [
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/house.png',
    },
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/mahal.jpg',
    },
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/splashbg.png',
    },
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/whitehouse.jpg',
    },
  ];
  bool isFavorite = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Favorite'),
        centerTitle: true,
        actions: [
          Icon(Icons.delete_outline),
          width5,
        ],
      ),
      body: SingleChildScrollView(
        child: ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: estateList.length,
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                width: 280,
                child: Row(
                  children: [
                    Stack(
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(20),
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(5),
                              topRight: Radius.circular(5)),
                          child: Image.asset(
                            estateList[index]['imagePath'],
                            width: 130,
                            height: 150,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Positioned(
                          top: 10,
                          left: 10,
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.favorite,
                              color: Colors.green,
                              size: 16,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 10,
                          left: 10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              estateList[index]['location'],
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              estateList[index]['title'],
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            height10,
                            Row(
                              children: [
                                const Icon(Icons.star,
                                    color: Colors.orange, size: 14),
                                const SizedBox(width: 4),
                                Text(
                                  estateList[index]['rating'],
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ],
                            ),
                            height5,
                            Row(
                              children: [
                                const Icon(Icons.location_on,
                                    size: 14, color: Colors.grey),
                                const SizedBox(width: 4),
                                Expanded(
                                  child: Text(
                                    estateList[index]['location'],
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 12,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            height10,
                            Text(
                              estateList[index]['price'],
                              style: const TextStyle(
                                color: Color(0xFF1F4C6B),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
      ),
    );
  }
}
