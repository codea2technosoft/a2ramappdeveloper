import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';
import 'package:rajasthani_real_estates/src/modules/onboarding.dart';

class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> with TickerProviderStateMixin {
  late AnimationController logoController;
  late Animation<double> logoAnimation;

  late AnimationController textController;
  late Animation<double> textFadeAnimation;

  @override
  void initState() {
    super.initState();
    logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    );

    logoAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: logoController,
        curve: Curves.easeOutBack,
      ),
    );

    textController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    textFadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: textController, curve: Curves.easeIn),
    );
    logoController.forward().whenComplete(() => textController.forward());
    // Future.delayed(const Duration(seconds: 2), () {
    //   final box = GetStorage();
    //   final isLoggedIn = box.read('userMobile') != null;

    //   if (isLoggedIn) {
    //     Get.offAll(() => const HomePageView());
    //   } else {
    //     Get.offAll(() => const LoginPageView());
    //   }
    // });
  }

  @override
  void dispose() {
    logoController.dispose();
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/img/splashbg.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF0A2C47).withOpacity(0.8),
                  const Color(0xFF0A2C47).withOpacity(0.18),
                ],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Spacer(),
                ScaleTransition(
                  scale: logoAnimation,
                  child: Image.asset(
                    'assets/img/logo.png',
                    width: 180,
                    height: 180,
                  ),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40.0),
                  child: AnimatedBuilder(
                    animation: textFadeAnimation,
                    builder: (context, child) {
                      return Opacity(
                        opacity: textFadeAnimation.value,
                        child: ElevatedButton(
                          onPressed: () {
                            Get.to(() => const OnboardingPageView());
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFB4F034),
                            foregroundColor: Colors.black,
                            elevation: 6,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          child: const Center(
                            child: Text(
                              "Let’s Start",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                height25,
                FadeTransition(
                  opacity: textFadeAnimation,
                  child: Column(
                    children: const [
                      Text(
                        'Made with ❤️ in Rajasthan',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      height5,
                      Text(
                        'v1.0.0',
                        style: TextStyle(color: Colors.white38, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                height20,
              ],
            ),
          ),
        ],
      ),
    );
  }
}
