import 'package:flutter/material.dart';
import 'package:rajasthani_real_estates/src/modules/home.dart';
import 'package:rajasthani_real_estates/src/modules/my_favorite.dart';
import 'package:rajasthani_real_estates/src/modules/profile_edit.dart';

class BottomBarPageView extends StatefulWidget {
  const BottomBarPageView({super.key});

  @override
  State<BottomBarPageView> createState() => _BottomBarPageViewState();
}

class _BottomBarPageViewState extends State<BottomBarPageView> {
  int _selectedIndex = 0;
  final PageController _pageController = PageController();

  final List<Widget> _pages = [
    HomePageView(),
    Center(child: Text('Search Page')),
    MyFavoritePageView(),
    ProfileEditPageView()
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _pageController.jumpToPage(index);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Image(
              image: AssetImage('assets/img/home.png'),
              height: 25,
              width: 25,
              color: Color(0xFF234F68),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Image(
              image: AssetImage('assets/img/search.png'),
              height: 25,
              width: 25,
              color: Color(0xFF234F68),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.favorite_border,
              color: Color(0xFF234F68),
              size: 30,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person_2_outlined,
              size: 30,
              color: Color(0xFF234F68),
            ),
            label: '',
          ),
        ],
      ),
    );
  }
}
