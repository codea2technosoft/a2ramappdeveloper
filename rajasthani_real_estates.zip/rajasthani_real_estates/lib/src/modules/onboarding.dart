import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';
import 'package:rajasthani_real_estates/src/modules/login.dart';

class OnboardingPageView extends StatefulWidget {
  const OnboardingPageView({super.key});

  @override
  State<OnboardingPageView> createState() => _OnboardingPageViewState();
}

class _OnboardingPageViewState extends State<OnboardingPageView> {
  final PageController _pageController = PageController();
  int currentPage = 0;

  final List<Map<String, String>> onboardingData = [
    {
      'image': 'assets/img/onboard1.png',
      'title': 'Find best place\nto stay in good price',
    },
    {
      'image': 'assets/img/onboard2.png',
      'title': 'Fast sell your property in just one click',
    },
    {
      'image': 'assets/img/onboard3.png',
      'title': 'Find perfect choice for your future house',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  PageView.builder(
                    controller: _pageController,
                    itemCount: onboardingData.length,
                    onPageChanged: (index) {
                      setState(() {
                        currentPage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 5),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Spacer(),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              child: Text.rich(
                                TextSpan(
                                  children: _buildTitleText(
                                      onboardingData[index]['title']!),
                                  style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            height10,
                            const Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                "Lorem ipsum dolor sit amet, consectetur\nadipisicing elit, sed.",
                                style:
                                    TextStyle(color: Colors.grey, fontSize: 15),
                              ),
                            ),
                            height20,
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.asset(
                                onboardingData[index]['image']!,
                                width: double.infinity,
                                height: 400,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  Positioned(
                    bottom: 90,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        onboardingData.length,
                        (dotIndex) => AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: currentPage == dotIndex ? 12 : 8,
                          height: currentPage == dotIndex ? 12 : 8,
                          decoration: BoxDecoration(
                            color: currentPage == dotIndex
                                ? Colors.white
                                : Colors.white54,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 20,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF84D65A),
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(
                              vertical: 12, horizontal: 30),
                        ),
                        onPressed: () {
                          if (currentPage < onboardingData.length - 1) {
                            _pageController.nextPage(
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeInOut,
                            );
                          } else {
                            Get.to(() => const LoginPageView());
                          }
                        },
                        child: Text(currentPage == onboardingData.length - 1
                            ? "Get Started"
                            : "Next"),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 30,
                    left: 0,
                    right: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Image.asset(
                            'assets/img/logo.png',
                            height: 40,
                            width: 40,
                          ),
                          TextButton(
                            onPressed: () {
                              Get.to(() => const LoginPageView());
                            },
                            child: const Text(
                              'skip',
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<InlineSpan> _buildTitleText(String title) {
    final parts = title.split(' ');
    return parts.map((word) {
      bool isHighlighted = word.toLowerCase() == "price" ||
          word.toLowerCase() == "click" ||
          word.toLowerCase() == "choice";
      return TextSpan(
        text: "$word ",
        style: TextStyle(
          color: isHighlighted ? Colors.blue : Colors.black,
        ),
      );
    }).toList();
  }
}
