import 'package:flutter/material.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';

class BeforeloginPageView extends StatefulWidget {
  const BeforeloginPageView({super.key});

  @override
  State<BeforeloginPageView> createState() => _BeforeloginPageViewState();
}

class _BeforeloginPageViewState extends State<BeforeloginPageView> {
  List imageList = [
    'assets/img/login1.png',
    'assets/img/login2.png',
    'assets/img/login3.png',
    'assets/img/login4.png',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.6,
                child: GridView.builder(
                  itemCount: imageList.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemBuilder: (context, index) {
                    return Image.asset(
                      imageList[index],
                      fit: BoxFit.cover,
                    );
                  },
                ),
              ),
              height30,
              Align(
                alignment: Alignment.centerLeft,
                child: RichText(
                    text: TextSpan(
                  text: 'Ready To ',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  children: [
                    TextSpan(
                      text: 'Explore?',
                      style: TextStyle(
                        color: const Color.fromARGB(153, 89, 88, 173),
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                )),
              ),
              SizedBox(height: 90),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF8BC83F),
                    foregroundColor: Colors.black87,
                    elevation: 5,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      "Contuinue",
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
