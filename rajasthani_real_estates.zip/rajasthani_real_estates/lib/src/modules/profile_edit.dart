import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rajasthani_real_estates/src/constant/app_color.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';
import 'package:rajasthani_real_estates/src/local_storage/local_storage.dart';

class ProfileEditPageView extends StatefulWidget {
  const ProfileEditPageView({super.key});

  @override
  State<ProfileEditPageView> createState() => _ProfileEditPageViewState();
}

class _ProfileEditPageViewState extends State<ProfileEditPageView> {
  TextEditingController nameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Profile'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            Align(
              alignment: Alignment.center,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: Image.asset(
                  'assets/img/man.jpg',
                  width: 150,
                  height: 150,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            height40,
            TextFormField(
                controller: nameController,
                decoration: InputDecoration(
                  hintText: userName(),
                  hintStyle: const TextStyle(color: Colors.black45),
                  fillColor: Colors.grey[200],
                  filled: true,
                  suffixIcon: const Icon(
                    Icons.person_2_outlined,
                    color: Color(0xFF252B5C),
                  ),
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(10),
                  ),
                )),
            height25,
            TextFormField(
                controller: mobileController,
                decoration: InputDecoration(
                  hintText: userMobile(),
                  hintStyle: const TextStyle(color: Colors.black45),
                  fillColor: Colors.grey[200],
                  filled: true,
                  suffixIcon: const Icon(
                    Icons.local_phone_outlined,
                    color: Color(0xFF252B5C),
                  ),
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(10),
                  ),
                )),
            height25,
            TextFormField(
                controller: passwordController,
                decoration: InputDecoration(
                  hintText: userPassword(),
                  hintStyle: const TextStyle(color: Colors.black45),
                  fillColor: Colors.grey[200],
                  filled: true,
                  suffixIcon: const Icon(
                    Icons.lock_open_outlined,
                    color: Color(0xFF252B5C),
                  ),
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(10),
                  ),
                )),
            height40,
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                    shape: ContinuousRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    fixedSize: Size(Get.width * 0.8, 50),
                    backgroundColor: elevatedButtonColor),
                onPressed: () {},
                child: Text(
                  'update',
                ))
          ],
        ),
      ),
    );
  }
}
