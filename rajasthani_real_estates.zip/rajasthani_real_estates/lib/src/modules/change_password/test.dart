// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';

// class KycPageView extends StatefulWidget {
//   const KycPageView({super.key});

//   @override
//   State<KycPageView> createState() => _KycPageViewState();
// }

// class _KycPageViewState extends State<KycPageView> {
//   File? _selectedImage;

//   Future<void> _pickImageFromGallery() async {
//   try {
//     final ImagePicker picker = ImagePicker();
//     final XFile? pickedFile = await picker.pickImage(source: ImageSource.gallery);

//     if (pickedFile != null && pickedFile.path.isNotEmpty) {
//       setState(() {
//         _selectedImage = File(pickedFile.path);
//       });
//     } else {
//       // User canceled or no valid image
//       print('No image selected or invalid image.');
//     }
//   } catch (e) {
//     print('Error picking image: $e');
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text('Failed to pick image: $e')),
//     );
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Gallery Image Picker")),
//       body: Padding(
//         padding: const EdgeInsets.all(20.0),
//         child: Column(
//           children: [
//             ElevatedButton(
//               onPressed: _pickImageFromGallery,
//               child: const Text("Choose Image from Gallery"),
//             ),
//             const SizedBox(height: 20),
//             _selectedImage != null
//                 ? Image.file(
//                     _selectedImage!,
//                     height: 200,
//                     width: double.infinity,
//                     fit: BoxFit.cover,
//                   )
//                 : const Text("No image selected"),
//           ],
//         ),
//       ),
//     );
//   }
// }
