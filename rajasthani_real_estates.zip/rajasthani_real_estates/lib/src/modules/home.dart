import 'package:flutter/material.dart';
import 'package:rajasthani_real_estates/src/constant/app_color.dart';
import 'package:rajasthani_real_estates/src/constant/custom_drawer.dart';
import 'package:rajasthani_real_estates/src/constant/size.dart';

class HomePageView extends StatefulWidget {
  const HomePageView({super.key});

  @override
  State<HomePageView> createState() => _HomePageViewState();
}

class _HomePageViewState extends State<HomePageView> {
  List estateList = [
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/house.png',
    },
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/mahal.jpg',
    },
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/splashbg.png',
    },
    {
      'title': 'Wings Tower',
      'price': '\$220/month',
      'rating': '4.9✨',
      'location': 'Jaipur Rajasthan',
      'imagePath': 'assets/img/whitehouse.jpg',
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFE6EEF5),
      ),
      drawer: CustomDrawer(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  height: 220,
                  decoration: const BoxDecoration(
                    color: Color(0xFFE6EEF5),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                  ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        height20,
                        Row(
                          children: [
                            const Icon(Icons.location_on,
                                color: Colors.black54),
                            width5,
                            const Text(
                              'Jaipur Rajasthan',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w500),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(30),
                              ),
                              child: const Icon(Icons.notifications_none),
                            ),
                            height10,
                            const CircleAvatar(
                              radius: 20,
                              backgroundImage:
                                  NetworkImage('https://i.pravatar.cc/300'),
                            ),
                          ],
                        ),
                        height30,
                        const Text.rich(
                          TextSpan(
                            text: 'Hey, ',
                            style: TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w500),
                            children: [
                              TextSpan(
                                text: 'Kalu Bhai!',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF1F4C6B)),
                              ),
                            ],
                          ),
                        ),
                        height5,
                        const Text(
                          "Let's start exploring",
                          style: TextStyle(fontSize: 16, color: Colors.black54),
                        ),
                        height20,
                        Container(
                          height: 55,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 2,
                                blurRadius: 5,
                              )
                            ],
                          ),
                          child: Row(
                            children: [
                              width15,
                              const Icon(Icons.search, color: Colors.grey),
                              width10,
                              const Expanded(
                                child: TextField(
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: 'Search House, Apartment, etc',
                                  ),
                                ),
                              ),
                              const Icon(Icons.mic, color: Colors.grey),
                              width10,
                              const Icon(Icons.tune, color: Colors.grey),
                              width10,
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            height25,
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  InkWell(
                      onTap: () {
                        showLocationBottomSheet(context);
                      },
                      child: categoryChip('All', selected: true)),
                  categoryChip('House'),
                  categoryChip('Apartment'),
                  categoryChip('Villa'),
                ],
              ),
            ),
            height20,
            SizedBox(
              height: 170,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  promoCard('Halloween\nSale!', 'assets/img/house.png'),
                  width10,
                  promoCard(
                    'Summer\nVacation!',
                    'assets/img/house.png',
                  ),
                ],
              ),
            ),
            height30,
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    'Featured Estates',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'view all',
                    style: TextStyle(fontSize: 14, color: Color(0xFF1F4C6B)),
                  )
                ],
              ),
            ),
            height15,
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    featuredCard(
                      title: 'Sky Dandelions Apartment',
                      location: 'Jaipur Rajasthan',
                      rating: '4.8✨',
                      price: '290',
                      imageUrl: 'assets/img/building.png',
                    ),
                    const SizedBox(width: 15),
                    featuredCard(
                      title: 'Sunset Villa',
                      location: 'Bali',
                      rating: '4.8✨',
                      price: '430',
                      imageUrl: 'assets/img/house.jpg',
                    ),
                  ],
                ),
              ),
            ),
            height20,
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       Text('Top Locations',
            //           style: GoogleFonts.lato(
            //             textStyle: const TextStyle(
            //                 color: Color((0xFF252B5C)),
            //                 fontSize: 18,
            //                 fontStyle: FontStyle.normal,
            //                 fontWeight: FontWeight.w700),
            //           )),
            //       Text('explore',
            //           style: TextStyle(
            //               color: Colors.black87,
            //               fontSize: 15,
            //               fontWeight: FontWeight.bold)),
            //     ],
            //   ),
            // ),
            // SizedBox(
            //   height: 80,
            //   child: ListView(
            //     scrollDirection: Axis.horizontal,
            //     children: [
            //       width20,
            //       circularLocationTile(
            //         imagePath: 'assets/img/house.png',
            //         title: 'Jaipur',
            //       ),
            //       width20,
            //       circularLocationTile(
            //         imagePath: 'assets/img/house.png',
            //         title: 'Jaisalmer',
            //       ),
            //       width20,
            //       circularLocationTile(
            //         imagePath: 'assets/img/house.png',
            //         title: 'Udaipur',
            //       ),
            //     ],
            //   ),
            // ),
            height20,
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Top Estate Agent',
                    style: TextStyle(
                        color: Color(0xFF252B5C),
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                  Text('explore',
                      style: TextStyle(
                          color: Color(0xFF252B5C),
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            height10,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                customColumn(imagePath: 'assets/img/man.jpg', title: 'Kalu'),
                customColumn(imagePath: 'assets/img/man.jpg', title: 'Kalu'),
                customColumn(imagePath: 'assets/img/man.jpg', title: 'Kalu'),
              ],
            ),
            height20,
            Text(
              'Explore Nearby Estates',
              style: TextStyle(
                  color: Color(0xFF252B5C),
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
            GridView.builder(
              itemCount: estateList.length,
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 2,
                mainAxisSpacing: 15,
                childAspectRatio: 0.75,
              ),
              itemBuilder: (context, index) {
                return EstateCard(
                  title: estateList[index]['title']!,
                  price: estateList[index]['price']!,
                  rating: estateList[index]['rating']!,
                  location: estateList[index]['location']!,
                  imagePath: estateList[index]['imagePath']!,
                );
              },
            ),
            height20
          ],
        ),
      ),
    );
  }

  Widget categoryChip(String title, {bool selected = false}) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Chip(
        label: Text(title),
        backgroundColor: selected ? const Color(0xFF1F4C6B) : Colors.grey[200],
        labelStyle: TextStyle(color: selected ? Colors.white : Colors.black),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  Widget promoCard(String title, String imageUrl) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: Stack(
        children: [
          Image.asset(
            imageUrl,
            width: 250,
            height: 200,
            fit: BoxFit.cover,
          ),
          Positioned(
              left: 0,
              bottom: 0,
              child: Container(
                height: 60,
                width: 110,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Color(0xFF234F68),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                child: Icon(Icons.arrow_forward, color: Colors.white),
              )),
          Positioned(
              top: 15,
              bottom: 0,
              left: 5,
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.deepOrange,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              )),
        ],
      ),
    );
  }

  Widget featuredCard({
    required String title,
    required String location,
    required String price,
    required String rating,
    required String imageUrl,
  }) {
    return Container(
      margin: const EdgeInsets.only(right: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      width: 280,
      child: Row(
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(
                  Radius.circular(20),
                ),
                child: Image.asset(
                  imageUrl,
                  width: 130,
                  height: 150,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 10,
                left: 10,
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.favorite,
                    color: Colors.green,
                    size: 16,
                  ),
                ),
              ),
              Positioned(
                bottom: 10,
                left: 10,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    "Apartment",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  height10,
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.orange, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        rating,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                  height5,
                  Row(
                    children: [
                      const Icon(Icons.location_on,
                          size: 14, color: Colors.grey),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          location,
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  height10,
                  Text(
                    "\$$price/month",
                    style: const TextStyle(
                      color: Color(0xFF1F4C6B),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget circularLocationTile({
    required String imagePath,
    required String title,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage(
              image: AssetImage(imagePath),
              fit: BoxFit.cover,
            ),
          ),
        ),
        width5,
        Text(
          title,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }
}

Widget customColumn({
  required String imagePath,
  required String title,
}) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          image: DecorationImage(
            image: AssetImage(imagePath),
            fit: BoxFit.cover,
          ),
        ),
      ),
      height5,
      Text(
        title,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      ),
    ],
  );
}

class EstateCard extends StatelessWidget {
  final String title;
  final String price;
  final String rating;
  final String location;
  final String imagePath;
  final bool isFavorite;

  const EstateCard({
    super.key,
    required this.title,
    required this.price,
    required this.rating,
    required this.location,
    required this.imagePath,
    this.isFavorite = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 180,
      margin: const EdgeInsets.only(right: 16),
      padding: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
                child: Image.asset(
                  imagePath,
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: isFavorite ? Colors.pink[100] : Colors.green[100],
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    size: 16,
                    color: isFavorite ? Colors.pink : Colors.green,
                  ),
                ),
              ),
              Positioned(
                bottom: 10,
                left: 10,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A6666),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    price,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                    ),
                  ),
                ),
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                height5,
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.orange, size: 14),
                    width5,
                    Text(
                      rating,
                      style: const TextStyle(fontSize: 12),
                    ),
                    width5,
                    const Icon(Icons.location_on, color: Colors.grey, size: 14),
                    const SizedBox(width: 2),
                    Expanded(
                      child: Text(
                        location,
                        style:
                            const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

void showLocationBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) {
      return Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const Text(
                  'Select Location',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1F4C6B),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    'Edit',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            height20,
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1F4C6B),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: const [
                  Icon(Icons.location_on, color: Colors.white),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Srengseng, Kembangan, West Jakarta City, Jakarta 11630',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            height15,
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF4F4F4),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: const [
                  Icon(Icons.location_on_outlined, color: Colors.grey),
                  width10,
                  Expanded(
                    child: Text(
                      'Petompon, Kec. Gajahmungkur, Kota Semarang, Jawa Tengah 50232',
                      style: TextStyle(color: Colors.black87),
                    ),
                  ),
                ],
              ),
            ),
            height25,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: elevatedButtonColor,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text('Choose Location',
                    style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      );
    },
  );
}
