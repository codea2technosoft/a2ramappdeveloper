import 'package:flutter/material.dart';

const height5 = SizedBox(height: 5);
const height10 = SizedBox(height: 10);
const height15 = SizedBox(height: 15);
const height20 = SizedBox(height: 20);
const height25 = SizedBox(height: 25);
const height30 = SizedBox(height: 30);
const height40 = SizedBox(height: 40);
const height45 = SizedBox(height: 45);
const height50 = SizedBox(height: 50);

const width5 = SizedBox(width: 5);
const width10 = SizedBox(width: 10);
const width15 = SizedBox(width: 15);
const width20 = SizedBox(width: 20);
