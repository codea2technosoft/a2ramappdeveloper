import 'package:flutter/material.dart';

Color elevatedButtonColor = Color(0xFF8FD147);