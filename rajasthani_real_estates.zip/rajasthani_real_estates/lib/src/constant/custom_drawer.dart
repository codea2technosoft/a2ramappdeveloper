import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rajasthani_real_estates/src/modules/change_password/change_password.dart';
import 'package:rajasthani_real_estates/src/modules/login.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});
// ram.app@12345#
// ram.app@a2technosoft.com
  @override
  Widget build(BuildContext context) {
    return Drawer(
      surfaceTintColor: Colors.white,
      child: Column(
        children: [
          buildDrawerHeader(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 10),
              children: [
                drawerItem(
                  icon: Icons.home_outlined,
                  title: 'Dashboard',
                  onTap: () => Get.back(),
                ),
                drawerItem(
                  icon: Icons.edit_note_rounded,
                  title: 'Edit Profile',
                  onTap: () => Get.back(),
                ),
                drawerItem(
                  icon: Icons.lock_open,
                  title: 'Change Password',
                  onTap: () => Get.to(() => const ChangePasswordPageView()),
                ),
                const Divider(),
                drawerExpansion(
                  icon: Icons.people_alt_outlined,
                  title: 'My Teams',
                  children: [
                    childItem('My team'),
                    childItem('List Customer'),
                    childItem('Id Card'),
                  ],
                ),
                drawerExpansion(
                  icon: Icons.eco,
                  title: 'Add Leads',
                  children: [
                    childItem('Sell Property'),
                    childItem('Buy Property'),
                    childItem('Apply For Loan'),
                  ],
                ),
                drawerExpansion(
                  icon: Icons.eco,
                  title: 'Leads Reports',
                  children: [
                    childItem('Lead Report'),
                    childItem('Response Report'),
                  ],
                ),
                drawerExpansion(
                  icon: Icons.pie_chart_outline,
                  title: 'Income Report',
                  children: [
                    childItem('Property Income'),
                    childItem('Property Royalty'),
                  ],
                ),
                Divider(),
                drawerItem(
                  icon: Icons.lock_open,
                  title: 'Log Out',
                  onTap: () {
                    showLogoutDialog(context);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildDrawerHeader() {
    return Container(
      height: 120,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.green.shade700,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 28,
            backgroundColor: Colors.white,
            child: Icon(Icons.person, color: Colors.green, size: 30),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "Welcome User",
                  style: TextStyle(color: Colors.white, fontSize: 17),
                ),
                Text(
                  "user@example.com",
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget drawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, size: 26, color: Colors.grey.shade800),
      title: Text(title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
      onTap: onTap,
      horizontalTitleGap: 12,
      visualDensity: const VisualDensity(vertical: -1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      hoverColor: Colors.grey.shade100,
    );
  }

  Widget drawerExpansion({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Theme(
      data: ThemeData().copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        leading: Icon(icon, color: Colors.grey.shade800),
        title: Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        childrenPadding: const EdgeInsets.only(left: 25),
        children: children,
      ),
    );
  }

  Widget childItem(String title) {
    return ListTile(
      dense: true,
      visualDensity: const VisualDensity(vertical: -3),
      title: Text(title, style: const TextStyle(fontSize: 14)),
      onTap: () => Get.back(),
    );
  }

  void showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text(
          'Logout',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: const Text(
          'Are you sure you want to logout?',
          style: TextStyle(fontSize: 15),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Get.offAll(() => const LoginPageView());
            },
            child: const Text(
              'Logout',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}
